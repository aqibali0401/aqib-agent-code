import {
  Injectable,
  OnModuleInit,
  Inject,
  LoggerService,
} from '@nestjs/common';
import { WINSTON_MODULE_NEST_PROVIDER } from 'nest-winston';
import { Client, Message } from 'azure-iot-device';
import { MqttWs as DeviceMqttWs } from 'azure-iot-device-mqtt';
import { SymmetricKeySecurityClient } from 'azure-iot-security-symmetric-key';
import {
  ProvisioningDeviceClient,
  RegistrationResult,
} from 'azure-iot-provisioning-device';
import { MqttWs as DpsMqtt } from 'azure-iot-provisioning-device-mqtt';
import * as crypto from 'crypto';
import { DEVICE_TYPE, EVENT_TYPE } from '../constants/app.constants';
import {
  getHostDeviceSnapshot,
  HostDeviceSnapshot,
} from '../utils/device-info';
import { formatDeviceId } from '../utils/device-id';

type TwinDesiredProperties = {
  telemetryInterval?: number;
  firstTimeRegistration?: boolean;
};
type TwinProperties = {
  desired: TwinDesiredProperties;
  reported: TwinDesiredProperties;
};

const provisioningHost =
  process.env.PROVISIONING_HOST || 'global.azure-devices-provisioning.net';
const idScope = process.env.PROVISIONING_IDSCOPE as string;
const groupSymmetricKey = process.env
  .PROVISIONING_GROUP_SYMMETRIC_KEY as string;
const appVersion = process.env.APP_VERSION as string;

@Injectable()
export class IoTService implements OnModuleInit {
  constructor(
    @Inject(WINSTON_MODULE_NEST_PROVIDER)
    private readonly logger: LoggerService
  ) {}

  private deriveDeviceKey(groupKey: string, deviceId: string): string {
    const key = Buffer.from(groupKey, 'base64');
    const hmac = crypto.createHmac('sha256', new Uint8Array(key));
    hmac.update(deviceId, 'utf8');
    return hmac.digest('base64');
  }

  async onModuleInit() {
    // Intentionally left blank to delay device initialization until after app start
  }

  async initializeAfterAppStart() {
    try {
      const snapshot = await getHostDeviceSnapshot();
      const model = snapshot.system.model || 'MODEL';
      const serial =
        snapshot.system.manufacturer ||
        snapshot.system.serial ||
        snapshot.system.uuid ||
        'SERIAL';
      const deviceId = formatDeviceId(DEVICE_TYPE, model, serial);
      snapshot.registrationId = deviceId;
      await this.openAndInitDevice(deviceId, snapshot);
    } catch (err) {
      this.logger.error('Failed to initialize IoT device on startup');
    }
  }

  async registerNewIotDevice(
    deviceId: string
  ): Promise<{ client: Client; registrationResult: RegistrationResult }> {
    if (!idScope) throw new Error('Missing PROVISIONING_IDSCOPE');
    if (!groupSymmetricKey)
      throw new Error('Missing PROVISIONING_GROUP_SYMMETRIC_KEY');

    const deviceSymmetricKey = this.deriveDeviceKey(
      groupSymmetricKey,
      deviceId
    );
    const securityClient: SymmetricKeySecurityClient =
      new SymmetricKeySecurityClient(deviceId, deviceSymmetricKey);

    const dpsTransport = new DpsMqtt();
    const provisioningClient = ProvisioningDeviceClient.create(
      provisioningHost,
      idScope,
      dpsTransport,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      securityClient as any
    );

    const registrationResult = await new Promise<RegistrationResult>(
      (resolve, reject) => {
        provisioningClient.register((err, result) => {
          if (err) return reject(err);
          if (!result)
            return reject(new Error('Registration result is undefined'));
          resolve(result);
        });
      }
    );

    this.logger.log(`DeviceId: ${registrationResult.deviceId}`);

    const transport = DeviceMqttWs;
    const deviceConnectionString = `HostName=${registrationResult.assignedHub};DeviceId=${registrationResult.deviceId};SharedAccessKey=${deviceSymmetricKey}`;
    const client = Client.fromConnectionString(
      deviceConnectionString,
      transport
    );
    return { client, registrationResult };
  }

  async openAndInitDevice(deviceId: string, deviceInfo: HostDeviceSnapshot) {
    const { client, registrationResult } = await this.registerNewIotDevice(
      deviceId
    );
    await client.open();
    this.logger.log(
      `Device connected to hub: ${registrationResult.assignedHub}`
    );
    this.applyRemoteActions(client);
    await this.readDeviceUpdates(client, deviceInfo);
    this.receiveMessages(client);
  }

  private async sendTelemetry(client: Client, data: Record<string, unknown>) {
    const message = new Message(JSON.stringify(data));
    await client.sendEvent(message);
  }

  private async readDeviceUpdates(
    client: Client,
    deviceInfo: HostDeviceSnapshot
  ) {
    const twin = await client.getTwin();
    const properties = twin.properties as unknown as TwinProperties;
    const isDesiredFirstTimeRegistration =
      properties.desired.firstTimeRegistration;

    const isReportedFirstTimeRegistration =
      properties.reported.firstTimeRegistration === undefined ||
      properties.reported.firstTimeRegistration === true
        ? true
        : false;

    if (isDesiredFirstTimeRegistration && isReportedFirstTimeRegistration) {
      await this.sendTelemetry(client, {
        eventType: EVENT_TYPE.NEW_DEVICE_REGISTRATION,
        deviceId: deviceInfo.registrationId,
        serial: deviceInfo.system.serial,
        name: deviceInfo.hostname,
        model: deviceInfo.system.model,
        uptime: deviceInfo.uptime * 1000, // Convert to milliseconds
        modelNumber: deviceInfo.system.model,
        serialNo: deviceInfo.system.serial,
      });

      await new Promise<void>((resolve) => {
        twin.properties.reported.update({ firstTimeRegistration: false }, () =>
          resolve()
        );
      });
      this.logger.log('New device event triggered');
    }
  }

  private receiveMessages(client: Client) {
    client.on('message', async (msg) => {
      try {
        const msgBuffer = msg.data;
        const msgStringified = msgBuffer.toString();
        this.logger.log(
          `Received new message on application version "${appVersion}": ${msgStringified}`
        );
        await client.complete(msg);
      } catch (err) {
        this.logger.error('Error completing message');
      }
    });
  }

  private applyRemoteActions(client: Client) {
    client.onDeviceMethod('reboot', async (request, response) => {
      try {
        this.logger.log('Reboot called');
        await response.send(200, 'Rebooting device...');
      } catch (err) {
        this.logger.error('Error responding to reboot method');
      }
    });

    client.onDeviceMethod('upgrade', async (request, response) => {
      if (!request?.payload?.version) {
        return response.send(403, 'Upgrade version missing');
      }
      const newVersion = request.payload.version;
      try {
        await response.send(
          200,
          `Upgrading device to version ${newVersion}...`
        );
        // this.startSendingTelemetry(client, telemetryInterval);
      } catch (err) {
        this.logger.error('Error responding to upgrade method');
      }
    });
  }
}
